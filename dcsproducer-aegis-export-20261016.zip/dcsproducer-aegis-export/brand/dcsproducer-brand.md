# DcsProducer® Creative Studio — Brand Guidelines

Official brand assets and rules for PDF, DOCX, HTML and WordPress outputs.

## Official Color Palette

| Name              | Hex       | Usage                        |
|-------------------|-----------|------------------------------|
| Ouro Premium      | `#D4AF37` | Primary gold, highlights, logo |
| Ouro Escuro       | `#B8972E` | Secondary gold, accents      |
| Preto Obsidiana   | `#0A0A0A` | Backgrounds, main text       |
| Grafite Metálico  | `#333333` | Secondary text, borders      |
| Branco Gelo       | `#F5F5F5` | Light backgrounds, contrast  |

## Typography

- **Título / Logo**: Cinzel or Trajan Pro (serif, elegant, high-end)
- **Corpo de texto**: Montserrat or Inter (clean sans-serif)

In PDFs generated with reportlab, prefer:
- Headings → Helvetica-Bold or a registered Cinzel-like font if available
- Body → Helvetica or similar clean sans

## Logo Assets (in this folder)

```
assets/
├── brand-board.png          # Full brand identity board (reference)
└── logos/
    ├── logo-main-gold.png   # Large main logo (gold version)
    ├── logo-horizontal.png  # Horizontal lockup
    └── logo-icon.png        # Icon / favicon size
```

**Variants available on the brand board**:
- Gold Executive Edition
- Dark Chrome Edition
- Platinum Edition
- Monocromático (preto/branco)

Use the **Gold** version as default for premium documents and footers.

## PDF Footer / Signature Pattern

Recommended footer for print-ready PDFs:

- Left: small logo-icon or horizontal logo (height ~18–24 pt)
- Center or right: “DcsProducer® Creative Studio” in gold (`#D4AF37`)
- Page number on the far right
- Optional thin gold line above the footer

Example structure (reportlab / Platypus):

```
[logo-icon]  DcsProducer®  ·  Creative Studio                    Página X
```

## HTML / WordPress Signature

Use the template in `assets/html-signature.html` for:

- End of blog posts
- Email signatures
- PDF → HTML conversion footers

## File Naming Convention

- PDF: `dcsproducer-[slug]-[YYYYMMDD].pdf`
- HTML: `dcsproducer-[slug]-[YYYYMMDD].html`
- DOCX: `dcsproducer-[slug]-[YYYYMMDD].docx`

## Tone of Voice

- Professional, premium, confident
- Clear and direct
- Creative yet sophisticated (AI + Design + Innovation)
- Prefer short paragraphs and strong visual hierarchy

## Applications Covered by Brand Board

- Cartão de visita
- Capa de portfólio premium
- Assinatura para PDF / HTML
- Marca d’água para apresentações
- Banner LinkedIn / redes sociais
- Ícone / Favicon
- Versão reduzida horizontal

When generating any document, default to these brand rules unless the user explicitly overrides them.
