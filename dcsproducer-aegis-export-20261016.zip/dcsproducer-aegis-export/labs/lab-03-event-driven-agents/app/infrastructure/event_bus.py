"""Event Bus in-memory simples (simula Redis Streams / Kafka para o lab)."""
from typing import Callable, Dict, List
from collections import defaultdict
from app.domain.models import DomainEvent, EventType, EventBusStats
from datetime import datetime
import uuid
import logging

logger = logging.getLogger(__name__)


class InMemoryEventBus:
    def __init__(self):
        self._handlers: Dict[EventType, List[Callable]] = defaultdict(list)
        self._history: List[DomainEvent] = []
        self._published = 0
        self._consumed = 0
        self._by_type: Dict[str, int] = defaultdict(int)

    def subscribe(self, event_type: EventType, handler: Callable):
        self._handlers[event_type].append(handler)
        logger.info(f"Subscribed handler to {event_type}")

    def publish(self, event_type: EventType, payload: dict, correlation_id: str = None) -> DomainEvent:
        event = DomainEvent(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            payload=payload,
            timestamp=datetime.utcnow(),
            correlation_id=correlation_id or str(uuid.uuid4())
        )
        self._history.append(event)
        self._published += 1
        self._by_type[event_type.value] += 1

        logger.info(f"Published {event_type} | id={event.event_id[:8]}")

        for handler in self._handlers.get(event_type, []):
            try:
                handler(event)
                self._consumed += 1
            except Exception as e:
                logger.error(f"Handler error on {event_type}: {e}")

        return event

    def stats(self) -> EventBusStats:
        return EventBusStats(
            total_published=self._published,
            total_consumed=self._consumed,
            by_type=dict(self._by_type)
        )

    def history(self, limit: int = 20) -> List[DomainEvent]:
        return self._history[-limit:]


# Singleton do lab
bus = InMemoryEventBus()
