from pydantic import BaseModel
from typing import Any, Dict, Optional, List
from datetime import datetime
from enum import Enum


class EventType(str, Enum):
    QUERY_RECEIVED = "query.received"
    RAG_COMPLETED = "rag.completed"
    AGENT_TRIGGERED = "agent.triggered"
    SECURITY_CHECKED = "security.checked"
    RESPONSE_READY = "response.ready"


class DomainEvent(BaseModel):
    event_id: str
    event_type: EventType
    payload: Dict[str, Any]
    timestamp: datetime
    correlation_id: Optional[str] = None


class EventBusStats(BaseModel):
    total_published: int
    total_consumed: int
    by_type: Dict[str, int]
