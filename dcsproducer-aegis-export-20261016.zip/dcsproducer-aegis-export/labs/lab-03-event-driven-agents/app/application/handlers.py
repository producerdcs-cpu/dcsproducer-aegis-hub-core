from app.domain.models import DomainEvent, EventType
from app.infrastructure.event_bus import bus
import logging

logger = logging.getLogger(__name__)


def on_query_received(event: DomainEvent):
    """Handler: ao receber query, dispara RAG."""
    question = event.payload.get("question", "")
    logger.info(f"[HANDLER] query.received → starting RAG for: {question[:50]}")
    # Simula conclusão de RAG e publica próximo evento
    bus.publish(
        EventType.RAG_COMPLETED,
        {"question": question, "sources_count": 3, "answer_preview": f"Resposta sobre: {question[:40]}..."},
        correlation_id=event.correlation_id
    )


def on_rag_completed(event: DomainEvent):
    """Handler: RAG concluído → dispara agent."""
    logger.info(f"[HANDLER] rag.completed → triggering agent")
    bus.publish(
        EventType.AGENT_TRIGGERED,
        {"from_rag": True, "sources": event.payload.get("sources_count", 0)},
        correlation_id=event.correlation_id
    )


def on_agent_triggered(event: DomainEvent):
    """Handler: agent disparado → security check."""
    logger.info(f"[HANDLER] agent.triggered → security check")
    bus.publish(
        EventType.SECURITY_CHECKED,
        {"approved": True, "findings": 0},
        correlation_id=event.correlation_id
    )


def on_security_checked(event: DomainEvent):
    """Handler: security OK → response ready."""
    logger.info(f"[HANDLER] security.checked → response.ready")
    bus.publish(
        EventType.RESPONSE_READY,
        {"status": "ok", "message": "Pipeline event-driven concluído com sucesso"},
        correlation_id=event.correlation_id
    )


def register_all_handlers():
    bus.subscribe(EventType.QUERY_RECEIVED, on_query_received)
    bus.subscribe(EventType.RAG_COMPLETED, on_rag_completed)
    bus.subscribe(EventType.AGENT_TRIGGERED, on_agent_triggered)
    bus.subscribe(EventType.SECURITY_CHECKED, on_security_checked)
    logger.info("All event handlers registered")
