from fastapi import FastAPI
from app.domain.models import EventType
from app.infrastructure.event_bus import bus
from app.application.handlers import register_all_handlers
import logging

app = FastAPI(
    title="Lab 03 — Event-Driven + Generative Agents",
    description="DcsProducer® · dcsproducer-aegis-hub-core · Event Bus + Agents",
    version="1.0.0"
)

logging.basicConfig(level=logging.INFO)
register_all_handlers()


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "lab-03-event-driven-agents",
        "skill": "dcsproducer-aegis-hub-core",
        "pillars": ["09 Event-Driven", "03 Serverless", "07 Observability"]
    }


@app.post("/trigger")
def trigger_pipeline(payload: dict):
    """Dispara o pipeline completo event-driven a partir de uma query."""
    question = payload.get("question", "O que é AEGIS?")
    event = bus.publish(
        EventType.QUERY_RECEIVED,
        {"question": question}
    )
    return {
        "correlation_id": event.correlation_id,
        "message": "Pipeline event-driven iniciado",
        "first_event": event.event_type
    }


@app.get("/events")
def list_events(limit: int = 20):
    history = bus.history(limit)
    return {
        "count": len(history),
        "events": [e.dict() for e in history]
    }


@app.get("/stats")
def stats():
    return bus.stats().dict()


@app.get("/")
def root():
    return {
        "message": "Lab 03 — Event-Driven + Generative Agents · DcsProducer®",
        "endpoints": ["/health", "/trigger", "/events", "/stats"],
        "skill": "dcsproducer-aegis-hub-core"
    }
