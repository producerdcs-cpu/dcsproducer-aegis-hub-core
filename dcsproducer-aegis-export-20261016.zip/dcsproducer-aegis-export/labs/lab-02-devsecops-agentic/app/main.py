from fastapi import FastAPI
from app.domain.models import AgentRequest, AgentResponse
from app.application.agent_service import execute_agent
from app.infrastructure.sast import run_sast, is_approved
import logging
import uuid

app = FastAPI(
    title="Lab 02 — DevSecOps + Agentic System",
    description="DcsProducer® · dcsproducer-aegis-hub-core · Shift-left SAST + Agent",
    version="1.0.0"
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "lab-02-devsecops-agentic",
        "skill": "dcsproducer-aegis-hub-core",
        "pillars": ["08 DevSecOps", "09 Event-Driven", "02 Microsserviços"]
    }


@app.post("/agent", response_model=AgentResponse)
def agent(req: AgentRequest):
    return execute_agent(req)


@app.post("/sast")
def sast_only(payload: dict):
    code = payload.get("code", "")
    findings = run_sast(code)
    return {
        "findings": [f.dict() for f in findings],
        "approved": is_approved(findings),
        "count": len(findings)
    }


@app.get("/")
def root():
    return {
        "message": "Lab 02 — DevSecOps + Agentic System · DcsProducer®",
        "endpoints": ["/health", "/agent", "/sast"],
        "skill": "dcsproducer-aegis-hub-core"
    }
