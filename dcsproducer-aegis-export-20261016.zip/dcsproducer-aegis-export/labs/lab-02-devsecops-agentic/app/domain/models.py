from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from enum import Enum


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class SecurityFinding(BaseModel):
    rule_id: str
    severity: Severity
    message: str
    file: Optional[str] = None
    line: Optional[int] = None


class AgentRequest(BaseModel):
    task: str
    code_snippet: Optional[str] = None
    language: str = "python"


class AgentResponse(BaseModel):
    request_id: str
    generated_code: str
    findings: List[SecurityFinding]
    approved: bool
    timestamp: datetime
    summary: str
