"""SAST mock simples — simula análise estática de segurança (shift-left)."""
from typing import List
from app.domain.models import SecurityFinding, Severity
import re


RULES = [
    {
        "id": "SEC001",
        "pattern": r"eval\s*\(",
        "severity": Severity.CRITICAL,
        "message": "Uso de eval() detectado — risco de code injection"
    },
    {
        "id": "SEC002",
        "pattern": r"exec\s*\(",
        "severity": Severity.CRITICAL,
        "message": "Uso de exec() detectado — risco de code injection"
    },
    {
        "id": "SEC003",
        "pattern": r"password\s*=\s*['\"][^'\"]+['\"]",
        "severity": Severity.HIGH,
        "message": "Possível hard-coded password"
    },
    {
        "id": "SEC004",
        "pattern": r"api[_-]?key\s*=\s*['\"][^'\"]+['\"]",
        "severity": Severity.HIGH,
        "message": "Possível hard-coded API key / secret"
    },
    {
        "id": "SEC005",
        "pattern": r"subprocess\.(call|run|Popen).*shell\s*=\s*True",
        "severity": Severity.HIGH,
        "message": "subprocess com shell=True — risco de command injection"
    },
    {
        "id": "SEC006",
        "pattern": r"pickle\.loads?",
        "severity": Severity.MEDIUM,
        "message": "Uso de pickle — risco de desserialização insegura"
    },
]


def run_sast(code: str, filename: str = "snippet.py") -> List[SecurityFinding]:
    findings = []
    lines = code.splitlines()
    for rule in RULES:
        for i, line in enumerate(lines, start=1):
            if re.search(rule["pattern"], line, re.IGNORECASE):
                findings.append(SecurityFinding(
                    rule_id=rule["id"],
                    severity=rule["severity"],
                    message=rule["message"],
                    file=filename,
                    line=i
                ))
    return findings


def is_approved(findings: List[SecurityFinding]) -> bool:
    """Aprovado apenas se não houver findings HIGH ou CRITICAL."""
    return not any(f.severity in (Severity.HIGH, Severity.CRITICAL) for f in findings)
