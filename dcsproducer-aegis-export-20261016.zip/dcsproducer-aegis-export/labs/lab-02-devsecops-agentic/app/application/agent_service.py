from datetime import datetime
from app.domain.models import AgentRequest, AgentResponse, SecurityFinding
from app.infrastructure.sast import run_sast, is_approved
import uuid
import logging

logger = logging.getLogger(__name__)


def generate_code_mock(task: str, language: str = "python") -> str:
    """Gerador mock de código (em produção seria um LLM real)."""
    templates = {
        "python": f'''# Gerado para: {task}
def process_data(data: dict) -> dict:
    """Processa dados de forma segura."""
    result = {{}}
    for key, value in data.items():
        if isinstance(value, str):
            result[key] = value.strip()
        else:
            result[key] = value
    return result


if __name__ == "__main__":
    sample = {{"name": "DcsProducer", "version": "1.0"}}
    print(process_data(sample))
''',
    }
    return templates.get(language, templates["python"])


def execute_agent(req: AgentRequest) -> AgentResponse:
    request_id = str(uuid.uuid4())
    logger.info("agent_started", extra={"task": req.task, "request_id": request_id})

    # 1. Gerar código
    if req.code_snippet:
        code = req.code_snippet
    else:
        code = generate_code_mock(req.task, req.language)

    # 2. Rodar SAST (shift-left)
    findings = run_sast(code)
    approved = is_approved(findings)

    summary = (
        f"Código {'APROVADO' if approved else 'REJEITADO'} pelo gate DevSecOps. "
        f"Findings: {len(findings)} "
        f"(critical/high bloqueiam deploy)."
    )

    logger.info(
        "agent_completed",
        extra={
            "request_id": request_id,
            "approved": approved,
            "findings_count": len(findings)
        }
    )

    return AgentResponse(
        request_id=request_id,
        generated_code=code,
        findings=findings,
        approved=approved,
        timestamp=datetime.utcnow(),
        summary=summary
    )
