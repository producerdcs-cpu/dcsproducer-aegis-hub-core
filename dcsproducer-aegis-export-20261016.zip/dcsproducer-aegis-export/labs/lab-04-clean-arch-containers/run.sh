#!/bin/bash
cd "$(dirname "$0")"
export PYTHONPATH=.
uvicorn app.main:app --host 0.0.0.0 --port 8004
