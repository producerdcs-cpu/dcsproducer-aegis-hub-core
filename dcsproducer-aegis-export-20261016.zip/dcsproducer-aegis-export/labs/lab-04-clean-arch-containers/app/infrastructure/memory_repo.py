"""Infrastructure — implementação concreta do repositório (in-memory)."""
from typing import List, Optional, Dict
from app.domain.entities import Project
from app.domain.ports import ProjectRepository


class InMemoryProjectRepository(ProjectRepository):
    def __init__(self):
        self._store: Dict[str, Project] = {}

    def save(self, project: Project) -> Project:
        self._store[project.id] = project
        return project

    def get_by_id(self, project_id: str) -> Optional[Project]:
        return self._store.get(project_id)

    def list_all(self) -> List[Project]:
        return list(self._store.values())

    def list_by_pillar(self, pillar: str) -> List[Project]:
        return [p for p in self._store.values() if p.pillar == pillar]
