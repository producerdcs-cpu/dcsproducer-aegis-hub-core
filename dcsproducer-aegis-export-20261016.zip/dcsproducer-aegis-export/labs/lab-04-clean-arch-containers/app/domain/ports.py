"""Ports (interfaces) — Domain não depende de infrastructure."""
from abc import ABC, abstractmethod
from typing import List, Optional
from app.domain.entities import Project


class ProjectRepository(ABC):
    @abstractmethod
    def save(self, project: Project) -> Project:
        pass

    @abstractmethod
    def get_by_id(self, project_id: str) -> Optional[Project]:
        pass

    @abstractmethod
    def list_all(self) -> List[Project]:
        pass

    @abstractmethod
    def list_by_pillar(self, pillar: str) -> List[Project]:
        pass
