"""Domain layer — regras de negócio puras (sem dependências externas)."""
from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class Project:
    id: str
    name: str
    status: str  # pending | in_progress | done
    pillar: str
    created_at: datetime
    updated_at: Optional[datetime] = None

    def mark_done(self):
        if self.status == "done":
            raise ValueError("Project already done")
        self.status = "done"
        self.updated_at = datetime.utcnow()

    def start(self):
        if self.status != "pending":
            raise ValueError("Can only start pending projects")
        self.status = "in_progress"
        self.updated_at = datetime.utcnow()
