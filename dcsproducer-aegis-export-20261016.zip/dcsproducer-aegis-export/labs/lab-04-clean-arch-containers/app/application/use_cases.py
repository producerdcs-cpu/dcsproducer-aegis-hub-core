from datetime import datetime
from typing import List
import uuid
from app.domain.entities import Project
from app.domain.ports import ProjectRepository


class CreateProject:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    def execute(self, name: str, pillar: str) -> Project:
        project = Project(
            id=str(uuid.uuid4())[:8],
            name=name,
            status="pending",
            pillar=pillar,
            created_at=datetime.utcnow()
        )
        return self.repo.save(project)


class StartProject:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    def execute(self, project_id: str) -> Project:
        project = self.repo.get_by_id(project_id)
        if not project:
            raise ValueError(f"Project {project_id} not found")
        project.start()
        return self.repo.save(project)


class CompleteProject:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    def execute(self, project_id: str) -> Project:
        project = self.repo.get_by_id(project_id)
        if not project:
            raise ValueError(f"Project {project_id} not found")
        project.mark_done()
        return self.repo.save(project)


class ListProjects:
    def __init__(self, repo: ProjectRepository):
        self.repo = repo

    def execute(self, pillar: str = None) -> List[Project]:
        if pillar:
            return self.repo.list_by_pillar(pillar)
        return self.repo.list_all()
