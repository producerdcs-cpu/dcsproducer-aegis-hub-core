from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.infrastructure.memory_repo import InMemoryProjectRepository
from app.application.use_cases import CreateProject, StartProject, CompleteProject, ListProjects
from datetime import datetime

app = FastAPI(
    title="Lab 04 — Arquitetura Limpa + Containers",
    description="DcsProducer® · dcsproducer-aegis-hub-core · Clean Architecture",
    version="1.0.0"
)

# Dependency Injection simples (sem framework)
repo = InMemoryProjectRepository()
create_uc = CreateProject(repo)
start_uc = StartProject(repo)
complete_uc = CompleteProject(repo)
list_uc = ListProjects(repo)


class CreateRequest(BaseModel):
    name: str
    pillar: str = "05 Arquitetura Limpa"


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "lab-04-clean-arch-containers",
        "skill": "dcsproducer-aegis-hub-core",
        "pillars": ["05 Arquitetura Limpa", "04 Containers", "06 DDD"]
    }


@app.post("/projects")
def create_project(req: CreateRequest):
    p = create_uc.execute(req.name, req.pillar)
    return {"id": p.id, "name": p.name, "status": p.status, "pillar": p.pillar}


@app.post("/projects/{project_id}/start")
def start_project(project_id: str):
    try:
        p = start_uc.execute(project_id)
        return {"id": p.id, "status": p.status}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/projects/{project_id}/complete")
def complete_project(project_id: str):
    try:
        p = complete_uc.execute(project_id)
        return {"id": p.id, "status": p.status}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/projects")
def list_projects(pillar: str = None):
    projects = list_uc.execute(pillar)
    return [
        {"id": p.id, "name": p.name, "status": p.status, "pillar": p.pillar}
        for p in projects
    ]


@app.get("/")
def root():
    return {
        "message": "Lab 04 — Arquitetura Limpa + Containers · DcsProducer®",
        "endpoints": ["/health", "/projects", "/projects/{id}/start", "/projects/{id}/complete"],
        "skill": "dcsproducer-aegis-hub-core"
    }
