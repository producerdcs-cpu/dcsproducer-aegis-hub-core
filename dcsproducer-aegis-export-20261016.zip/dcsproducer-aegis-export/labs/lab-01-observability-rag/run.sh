#!/bin/bash
set -e

echo "=== Lab 01 — Observability + RAG · DcsProducer® ==="
echo "Skill: dcsproducer-aegis-hub-core"
echo ""

cd "$(dirname "$0")"

# Instalar deps se necessário
if [ ! -d ".venv" ]; then
  echo "Criando virtualenv..."
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -q -r requirements.txt
else
  source .venv/bin/activate
fi

echo "Iniciando servidor em http://0.0.0.0:8000"
echo "Endpoints: /health  /metrics  /query"
echo ""

uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
