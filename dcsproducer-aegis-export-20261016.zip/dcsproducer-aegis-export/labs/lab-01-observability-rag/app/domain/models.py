from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime


class QueryRequest(BaseModel):
    question: str
    top_k: int = 3


class Document(BaseModel):
    id: str
    content: str
    score: float


class QueryResponse(BaseModel):
    request_id: str
    answer: str
    sources: List[Document]
    latency_ms: float
    timestamp: datetime
