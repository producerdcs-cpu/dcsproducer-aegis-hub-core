import time
from datetime import datetime
from app.domain.models import QueryRequest, QueryResponse, Document
from app.infrastructure.rag import simple_retrieve, simple_generate
from app.infrastructure.logging import get_request_id
from app.infrastructure.metrics import Timer, metrics
import logging

logger = logging.getLogger(__name__)


def execute_query(req: QueryRequest) -> QueryResponse:
    request_id = get_request_id()
    logger.info("query_started", extra={"question": req.question, "top_k": req.top_k})

    with Timer("rag_query"):
        sources = simple_retrieve(req.question, req.top_k)
        answer = simple_generate(req.question, sources)

    # Calcula latência aproximada a partir das métricas (último valor)
    latency = 0.0
    if metrics.latencies.get("rag_query"):
        latency = metrics.latencies["rag_query"][-1]

    response = QueryResponse(
        request_id=request_id,
        answer=answer,
        sources=sources,
        latency_ms=round(latency, 2),
        timestamp=datetime.utcnow()
    )

    logger.info(
        "query_completed",
        extra={
            "request_id": request_id,
            "sources_count": len(sources),
            "latency_ms": response.latency_ms
        }
    )
    return response
