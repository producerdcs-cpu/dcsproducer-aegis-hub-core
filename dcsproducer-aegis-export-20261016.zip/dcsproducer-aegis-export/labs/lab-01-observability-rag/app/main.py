from fastapi import FastAPI, Request
from app.domain.models import QueryRequest, QueryResponse
from app.application.query_service import execute_query
from app.infrastructure.logging import setup_logging, get_request_id, request_id_var
from app.infrastructure.metrics import metrics
import logging
import uuid

app = FastAPI(
    title="Lab 01 — Observability + RAG",
    description="DcsProducer® · dcsproducer-aegis-hub-core",
    version="1.0.0"
)

logger = setup_logging()


@app.middleware("http")
async def add_request_id(request: Request, call_next):
    rid = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    request_id_var.set(rid)
    response = await call_next(request)
    response.headers["X-Request-ID"] = rid
    return response


@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "lab-01-observability-rag",
        "skill": "dcsproducer-aegis-hub-core"
    }


@app.get("/metrics")
def get_metrics():
    return metrics.snapshot()


@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest):
    return execute_query(req)


@app.get("/")
def root():
    return {
        "message": "Lab 01 — Observability + RAG · DcsProducer®",
        "endpoints": ["/health", "/metrics", "/query"],
        "skill": "dcsproducer-aegis-hub-core"
    }
