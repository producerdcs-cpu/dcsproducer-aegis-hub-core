import time
from collections import defaultdict
from threading import Lock
from typing import Dict


class SimpleMetrics:
    """Métricas in-memory simples para o Lab 01."""

    def __init__(self):
        self._lock = Lock()
        self.counters: Dict[str, int] = defaultdict(int)
        self.latencies: Dict[str, list] = defaultdict(list)

    def inc(self, name: str, value: int = 1):
        with self._lock:
            self.counters[name] += value

    def observe_latency(self, name: str, latency_ms: float):
        with self._lock:
            self.latencies[name].append(latency_ms)

    def snapshot(self) -> dict:
        with self._lock:
            result = {
                "counters": dict(self.counters),
                "latencies": {}
            }
            for k, values in self.latencies.items():
                if values:
                    result["latencies"][k] = {
                        "count": len(values),
                        "avg_ms": round(sum(values) / len(values), 2),
                        "max_ms": round(max(values), 2),
                        "min_ms": round(min(values), 2),
                    }
            return result


metrics = SimpleMetrics()


class Timer:
    def __init__(self, name: str):
        self.name = name
        self.start = None

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, *args):
        elapsed_ms = (time.perf_counter() - self.start) * 1000
        metrics.observe_latency(self.name, elapsed_ms)
        metrics.inc(f"{self.name}_total")
