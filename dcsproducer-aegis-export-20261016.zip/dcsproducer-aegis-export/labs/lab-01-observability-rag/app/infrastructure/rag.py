from typing import List
from app.domain.models import Document
import hashlib


# Corpus mock (simula base de conhecimento DcsProducer)
CORPUS = [
    {"id": "doc1", "content": "Os 9 Pilares de Engenharia de Software do DcsProducer incluem DevOps, Microsserviços, Serverless, Orquestração de Containers, Arquitetura Limpa, DDD, Observability, DevSecOps e Event-Driven Architecture."},
    {"id": "doc2", "content": "AEGIS Layer é a camada transversal de governança, proteção e inteligência que cobre todos os pilares e o Hub Core MetaRAG."},
    {"id": "doc3", "content": "Observability combina logs estruturados, métricas e traces para dar visibilidade completa ao comportamento do sistema em produção."},
    {"id": "doc4", "content": "Retrieval-Augmented Generation (RAG) recupera documentos relevantes e os injeta no contexto do LLM para respostas fundamentadas."},
    {"id": "doc5", "content": "Arquitetura Limpa separa domain, application e infrastructure para que regras de negócio sobrevivam à troca de frameworks."},
]


def simple_retrieve(question: str, top_k: int = 3) -> List[Document]:
    """Retriever mock baseado em sobreposição de palavras (para o lab)."""
    q_words = set(question.lower().split())
    scored = []
    for doc in CORPUS:
        d_words = set(doc["content"].lower().split())
        overlap = len(q_words & d_words)
        score = overlap / max(len(q_words), 1)
        scored.append((score, doc))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    for score, doc in scored[:top_k]:
        results.append(Document(id=doc["id"], content=doc["content"], score=round(score, 3)))
    return results


def simple_generate(question: str, sources: List[Document]) -> str:
    """Gerador mock — em produção seria um LLM real."""
    if not sources:
        return "Não encontrei informações relevantes no corpus."
    context = " | ".join([s.content for s in sources])
    return f"Com base no corpus DcsProducer: {context[:300]}..."
