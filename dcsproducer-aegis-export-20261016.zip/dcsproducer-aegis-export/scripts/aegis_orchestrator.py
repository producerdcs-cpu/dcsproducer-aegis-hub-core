#!/usr/bin/env python3
"""
AEGIS Orchestrator — Script Geral de Governança de Produção
============================================================
Skill: dcsproducer-aegis-hub-core

Interliga e alinha de forma coordenada:
  - Hub Core MetaRAG
  - 9 Pilares de Engenharia de Software
  - Camada AEGIS (Governança · Proteção · Inteligência)
  - Skills irmãs do ecossistema DcsProducer®
  - Laboratórios sandbox (01–04)

Uso:
  python scripts/aegis_orchestrator.py                  # status completo
  python scripts/aegis_orchestrator.py --init           # inicializa contexto de sessão
  python scripts/aegis_orchestrator.py --lab 01         # prepara lab específico
  python scripts/aegis_orchestrator.py --status         # snapshot de alinhamento
  python scripts/aegis_orchestrator.py --json           # saída em JSON

Acionado no início de qualquer conversa quando a skill dcsproducer-aegis-hub-core
é ativada, garantindo governança coordenada de produção.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Constantes do Ecossistema
# ---------------------------------------------------------------------------

SKILL_NAME = "dcsproducer-aegis-hub-core"
SKILL_ROOT = Path(__file__).resolve().parent.parent
ARTIFACTS = Path("/home/workdir/artifacts")
PROGRESS_FILE = ARTIFACTS / "dcs-learning-progress.json"
SESSION_CONTEXT = ARTIFACTS / "aegis-session-context.json"

NINE_PILLARS = [
    {"id": "01", "name": "DevOps", "type": "classic"},
    {"id": "02", "name": "Microsserviços", "type": "classic"},
    {"id": "03", "name": "Serverless", "type": "classic"},
    {"id": "04", "name": "Orquestração de Containers", "type": "classic"},
    {"id": "05", "name": "Arquitetura Limpa", "type": "classic"},
    {"id": "06", "name": "Domain-Driven Design", "type": "classic"},
    {"id": "07", "name": "Observability", "type": "new"},
    {"id": "08", "name": "DevSecOps / Security-by-Design", "type": "new"},
    {"id": "09", "name": "Event-Driven Architecture", "type": "new"},
]

AEGIS_LAYER = {
    "name": "AEGIS Layer",
    "role": "Governança · Proteção · Inteligência",
    "scope": "Transversal a todos os 9 pilares + Hub Core MetaRAG",
    "principles": [
        "Toda decisão de produção passa pelo gate AEGIS",
        "Observability e Security-by-Design desde o dia 1",
        "Eventos e contratos explícitos entre skills",
        "Rastreabilidade completa (request-id → evidência → registro)",
    ],
}

SISTER_SKILLS = [
    {
        "name": "dcs-learning-orchestrator",
        "role": "Planos de estudo, competências, progresso de módulos do Hub",
        "path": "/home/workdir/.grok/skills/dcs-learning-orchestrator",
        "triggers": ["executar plano de estudos", "Go estudar módulo", "registrar competências"],
    },
    {
        "name": "dcs-system-design-master",
        "role": "Decisões de arquitetura, escala, RAG, agentes",
        "path": "/home/workdir/.grok/skills/dcs-system-design-master",
        "triggers": ["Design Mestre do Sistema", "arquitetura de especialistas", "RAG GenAI"],
    },
    {
        "name": "six-pillars-engineer",
        "role": "Vocabulário dos pilares, checklist de revisão de outputs de IA",
        "path": "/home/workdir/.grok/skills/six-pillars-engineer",
        "triggers": ["6 pilares", "me ajude ser estrategista", "checklist de revisão IA"],
    },
    {
        "name": "career-gap-analyzer",
        "role": "Gaps, metas OKR/SMART, competências desenvolvidas",
        "path": "/home/workdir/.grok/skills/career-gap-analyzer",
        "triggers": ["Go analisar", "gaps de carreira", "match de vagas"],
    },
    {
        "name": "pdf-wordpress-editor",
        "role": "Relatórios, PDFs, HTML WordPress, planilha Lista_Projetos",
        "path": "/home/workdir/.grok/skills/pdf-wordpress-editor",
        "triggers": ["pdf-wordpress-editor", "planilha de projetos", "documento para WordPress"],
    },
]

LABS = [
    {
        "id": "01",
        "name": "Observability + RAG",
        "path": str(ARTIFACTS / "lab-01-observability-rag"),
        "port": 8000,
        "pillars": ["07", "05", "01"],
        "status": "validated",
    },
    {
        "id": "02",
        "name": "DevSecOps + Agentic System",
        "path": str(ARTIFACTS / "lab-02-devsecops-agentic"),
        "port": 8002,
        "pillars": ["08", "09", "02"],
        "status": "validated",
    },
    {
        "id": "03",
        "name": "Event-Driven + Generative Agents",
        "path": str(ARTIFACTS / "lab-03-event-driven-agents"),
        "port": 8003,
        "pillars": ["09", "03", "07"],
        "status": "validated",
    },
    {
        "id": "04",
        "name": "Arquitetura Limpa + Containers",
        "path": str(ARTIFACTS / "lab-04-clean-arch-containers"),
        "port": 8004,
        "pillars": ["05", "04", "06"],
        "status": "validated",
    },
]

HUB_CORE = {
    "name": "Hub Core MetaRAG",
    "url": "https://dcsproducer-hub-pqj9.vercel.app",
    "modules": "01–12",
    "role": "Fonte de competências, metas e corpus dinâmico",
}


# ---------------------------------------------------------------------------
# Funções de Governança AEGIS
# ---------------------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def check_path(path: str | Path) -> bool:
    return Path(path).exists()


def skill_exists(skill: Dict) -> bool:
    return check_path(skill["path"]) and check_path(Path(skill["path"]) / "SKILL.md")


def lab_exists(lab: Dict) -> bool:
    return check_path(lab["path"]) and check_path(Path(lab["path"]) / "app" / "main.py")


def load_progress() -> Dict[str, Any]:
    if PROGRESS_FILE.exists():
        try:
            return json.loads(PROGRESS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "last_updated": None,
        "modulos": {},
        "registros_skills": {s["name"]: [] for s in SISTER_SKILLS},
        "aegis": {"session_count": 0, "last_session": None},
    }


def save_session_context(ctx: Dict[str, Any]) -> None:
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    SESSION_CONTEXT.write_text(json.dumps(ctx, indent=2, ensure_ascii=False), encoding="utf-8")


def build_ecosystem_snapshot() -> Dict[str, Any]:
    """Snapshot completo do alinhamento sob governança AEGIS."""
    sisters = []
    for s in SISTER_SKILLS:
        sisters.append({
            "name": s["name"],
            "role": s["role"],
            "available": skill_exists(s),
            "triggers": s["triggers"],
        })

    labs_status = []
    for lab in LABS:
        labs_status.append({
            "id": lab["id"],
            "name": lab["name"],
            "available": lab_exists(lab),
            "port": lab["port"],
            "pillars": lab["pillars"],
            "status": lab["status"] if lab_exists(lab) else "missing",
        })

    return {
        "skill": SKILL_NAME,
        "timestamp": now_iso(),
        "governance": AEGIS_LAYER,
        "hub_core": HUB_CORE,
        "nine_pillars": NINE_PILLARS,
        "sister_skills": sisters,
        "labs": labs_status,
        "alignment": {
            "all_sisters_present": all(s["available"] for s in sisters),
            "all_labs_validated": all(l["status"] == "validated" for l in labs_status),
            "aegis_active": True,
            "production_ready": all(s["available"] for s in sisters) and all(
                l["status"] == "validated" for l in labs_status
            ),
        },
    }


def init_session() -> Dict[str, Any]:
    """Inicializa contexto de sessão sob governança AEGIS."""
    snapshot = build_ecosystem_snapshot()
    progress = load_progress()

    session = {
        "session_id": f"aegis-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}",
        "started_at": now_iso(),
        "skill": SKILL_NAME,
        "governance": "AEGIS",
        "mode": "production",
        "snapshot": snapshot,
        "progress_summary": {
            "last_updated": progress.get("last_updated"),
            "modulos_count": len(progress.get("modulos", {})),
        },
        "coordination_rules": [
            "Toda ação de produção deve respeitar o gate AEGIS (Security + Observability)",
            "Skills irmãs são delegadas, nunca substituídas",
            "Labs são a evidência prática dos pilares",
            "Registro contínuo em dcs-learning-progress.json e skills irmãs",
            "Documentação formal via pdf-wordpress-editor com brand DcsProducer®",
        ],
    }

    # Atualiza contador de sessões
    progress.setdefault("aegis", {})
    progress["aegis"]["session_count"] = progress["aegis"].get("session_count", 0) + 1
    progress["aegis"]["last_session"] = session["session_id"]
    progress["last_updated"] = now_iso()

    try:
        ARTIFACTS.mkdir(parents=True, exist_ok=True)
        PROGRESS_FILE.write_text(json.dumps(progress, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

    save_session_context(session)
    return session


def prepare_lab(lab_id: str) -> Dict[str, Any]:
    """Prepara contexto de um laboratório específico sob AEGIS."""
    lab = next((l for l in LABS if l["id"] == lab_id), None)
    if not lab:
        return {"error": f"Lab {lab_id} não encontrado", "available": [l["id"] for l in LABS]}

    exists = lab_exists(lab)
    return {
        "lab": lab,
        "available": exists,
        "run_command": f"cd {lab['path']} && export PYTHONPATH=. && uvicorn app.main:app --host 0.0.0.0 --port {lab['port']}",
        "health_url": f"http://127.0.0.1:{lab['port']}/health",
        "aegis_gate": {
            "observability_required": "07" in lab["pillars"],
            "security_required": "08" in lab["pillars"],
            "event_driven": "09" in lab["pillars"],
            "clean_architecture": "05" in lab["pillars"],
        },
        "message": f"Lab {lab_id} ({lab['name']}) preparado sob governança AEGIS" if exists else f"Lab {lab_id} não encontrado no sandbox",
    }


def print_status(snapshot: Dict[str, Any], as_json: bool = False) -> None:
    if as_json:
        print(json.dumps(snapshot, indent=2, ensure_ascii=False))
        return

    print("=" * 64)
    print("  AEGIS ORCHESTRATOR · Governança de Produção DcsProducer®")
    print("=" * 64)
    print(f"  Skill      : {snapshot['skill']}")
    print(f"  Timestamp  : {snapshot['timestamp']}")
    print(f"  Governance : {snapshot['governance']['name']} — {snapshot['governance']['role']}")
    print("-" * 64)

    print("\n  [HUB CORE]")
    print(f"    {snapshot['hub_core']['name']}  ({snapshot['hub_core']['url']})")

    print("\n  [9 PILARES]")
    for p in snapshot["nine_pillars"]:
        mark = "★" if p["type"] == "new" else "·"
        print(f"    {mark} {p['id']}  {p['name']}")

    print("\n  [AEGIS LAYER]")
    for principle in snapshot["governance"]["principles"]:
        print(f"    ✓ {principle}")

    print("\n  [SKILLS IRMÃS]")
    for s in snapshot["sister_skills"]:
        status = "OK" if s["available"] else "MISSING"
        print(f"    [{status}] {s['name']}")
        print(f"           → {s['role']}")

    print("\n  [LABORATÓRIOS]")
    for lab in snapshot["labs"]:
        status = lab["status"].upper()
        print(f"    [{status}] Lab {lab['id']} — {lab['name']}  (port {lab['port']})")

    align = snapshot["alignment"]
    print("\n  [ALINHAMENTO DE PRODUÇÃO]")
    print(f"    Skills irmãs presentes : {'SIM' if align['all_sisters_present'] else 'NÃO'}")
    print(f"    Labs validados         : {'SIM' if align['all_labs_validated'] else 'NÃO'}")
    print(f"    AEGIS ativo            : {'SIM' if align['aegis_active'] else 'NÃO'}")
    print(f"    Production Ready       : {'SIM ✓' if align['production_ready'] else 'NÃO'}")
    print("=" * 64)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AEGIS Orchestrator — Governança de Produção DcsProducer®"
    )
    parser.add_argument("--init", action="store_true", help="Inicializa contexto de sessão AEGIS")
    parser.add_argument("--status", action="store_true", help="Snapshot de alinhamento (padrão)")
    parser.add_argument("--lab", type=str, help="Prepara lab específico (01|02|03|04)")
    parser.add_argument("--json", action="store_true", help="Saída em JSON")
    args = parser.parse_args()

    if args.init:
        session = init_session()
        if args.json:
            print(json.dumps(session, indent=2, ensure_ascii=False))
        else:
            print(f"Sessão AEGIS inicializada: {session['session_id']}")
            print(f"Contexto salvo em: {SESSION_CONTEXT}")
            print_status(session["snapshot"])
        return

    if args.lab:
        result = prepare_lab(args.lab.zfill(2) if args.lab.isdigit() else args.lab)
        if args.json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(result.get("message", result))
            if "run_command" in result:
                print(f"\nComando: {result['run_command']}")
                print(f"Health : {result['health_url']}")
        return

    # Default: status
    snapshot = build_ecosystem_snapshot()
    print_status(snapshot, as_json=args.json)


if __name__ == "__main__":
    main()
