---
name: dcsproducer-aegis-hub-core
description: Skill integradora central do ecossistema DcsProducer. Une Hub Core MetaRAG, camada AEGIS de governança/proteção/inteligência, os 9 Pilares de Engenharia de Software e laboratórios práticos via sandbox. Ative com dcsproducer-aegis-hub-core, AEGIS, Hub Core, 9 pilares, laboratório sandbox, integrar ecossistema DcsProducer ou pedidos de orquestração total das skills irmãs.
---

# DcsProducer AEGIS Hub Core

Skill central que integra e orquestra todo o ecossistema DcsProducer®.

## Componentes Integrados

- **Hub Core** — MetaRAG (https://dcsproducer-hub-pqj9.vercel.app) + módulos 01-12
- **AEGIS Layer** — Governança, proteção, segurança e inteligência transversal
- **9 Pilares de Engenharia de Software**
- **Skills irmãs** — dcs-learning-orchestrator, dcs-system-design-master, six-pillars-engineer, career-gap-analyzer, pdf-wordpress-editor
- **Laboratórios práticos** — Sandbox remoto com exercícios hands-on

## Os 9 Pilares

01. DevOps  
02. Microsserviços  
03. Serverless  
04. Orquestração de Containers  
05. Arquitetura Limpa  
06. Domain-Driven Design  
07. Observability  
08. DevSecOps / Security-by-Design  
09. Event-Driven Architecture  

**AEGIS Layer** atua de forma transversal sobre todos os 9 pilares + Hub Core.

## Quando Ativar

- Usuário menciona `dcsproducer-aegis-hub-core`, AEGIS, Hub Core, 9 pilares
- Pedidos de integração total do ecossistema
- Solicitação de laboratórios práticos via sandbox
- Necessidade de orquestrar múltiplas skills irmãs em um único fluxo
- Evolução de competências alinhadas ao Hub MetaRAG + Lista_Projetos

## Workflow Principal (Governança AEGIS)

**Sempre iniciar com o script geral de orquestração** (alinhamento coordenado de produção):

```bash
python scripts/aegis_orchestrator.py --init
```

Isso interliga automaticamente: Hub Core + 9 Pilares + AEGIS Layer + todas as skills irmãs + labs validados, sob a Governança principal de produção.

1. **Init AEGIS (obrigatório no início de qualquer conversa)**  
   Executar `scripts/aegis_orchestrator.py --init`  
   Gera sessão, snapshot de alinhamento e contexto em `artifacts/aegis-session-context.json`.

2. **Diagnóstico rápido**  
   Identificar qual(is) pilar(es), módulo do Hub ou componente AEGIS está em foco.

3. **Orquestração coordenada**  
   - Extrair conteúdo do Hub (quando aplicável)  
   - Aplicar vocabulário dos 9 pilares + AEGIS  
   - Delegar para skills irmãs quando necessário (learning, design, career-gap, pdf)  
   - Respeitar gate AEGIS (Security + Observability) em toda ação de produção

4. **Laboratórios Sandbox**  
   Preparar com `python scripts/aegis_orchestrator.py --lab 01` (ou 02/03/04)  
   Executar exercícios práticos no ambiente remoto.

5. **Registro contínuo**  
   Atualizar progresso em `dcs-learning-progress.json` e registrar nas skills irmãs.

6. **Documentação**  
   Gerar saídas formais via pdf-wordpress-editor com brand DcsProducer®.

## Laboratórios Disponíveis

| Lab | Nome                              | Pilares principais                  | Status     |
|-----|-----------------------------------|-------------------------------------|------------|
| 01  | Observability + RAG               | 07, 05, 01                          | Validado   |
| 02  | DevSecOps + Agentic System        | 08, 09, 02                          | Validado   |
| 03  | Event-Driven + Generative Agents  | 09, 03, 07                          | Validado   |
| 04  | Arquitetura Limpa + Containers    | 05, 04, 06                          | Validado   |

## Referências Internas

- `scripts/aegis_orchestrator.py` — **Script geral de governança** (init, status, labs, alinhamento de produção)
- `references/fundamentos-e-funcionalidades.md` — Fundamentos, onde visualizar e como aplicar no ecossistema
- `references/9-pilares-visual.md` — Visual oficial dos 9 pilares + AEGIS
- `references/lab-01-observability-rag.md` — Guia do Lab 01
- Skills irmãs: dcs-learning-orchestrator, dcs-system-design-master, six-pillars-engineer, career-gap-analyzer, pdf-wordpress-editor

## Estilo de Resposta

- Português (quando a conversa estiver em português)
- Conciso, técnico e acionável
- Sempre oferecer próximo passo concreto (próximo lab, registro de competência, geração de documento)
