# Lab 01 — Observability + RAG

**Pilares:** 07 Observability · 05 Arquitetura Limpa · 01 DevOps  
**Skill:** dcsproducer-aegis-hub-core  
**Ambiente:** Sandbox remoto (Linux)

## Objetivo

Construir um mini-serviço RAG com:

- Logging estruturado (JSON)
- Métricas básicas (contadores + latência)
- Traces simples (request-id)
- Separação de camadas (Arquitetura Limpa)
- Pipeline mínimo de DevOps (script de execução + healthcheck)

## Estrutura do Lab

```
artifacts/lab-01-observability-rag/
├── app/
│   ├── domain/          # Regras de negócio (RAG query)
│   ├── application/     # Casos de uso
│   ├── infrastructure/  # LLM mock + retriever + logging
│   └── main.py
├── logs/
├── metrics/
├── requirements.txt
└── run.sh
```

## Passos do Lab

1. Criar estrutura de pastas e arquivos base
2. Implementar logging estruturado + request-id
3. Implementar métricas simples (contagem de queries + latência)
4. Implementar um retriever + gerador mock (simula RAG)
5. Expor endpoint / health e /query
6. Rodar e validar logs + métricas

## Critérios de Conclusão

- [ ] Logs em JSON com request-id, nível, timestamp e contexto
- [ ] Métricas de contagem e latência registradas
- [ ] Camadas separadas (domain / application / infrastructure)
- [ ] Script `run.sh` funcional
- [ ] Healthcheck responde 200
