# Fundamentos e Funcionalidades — dcsproducer-aegis-hub-core

**Skill integradora central do ecossistema DcsProducer®**

## 1. O que é

A skill `dcsproducer-aegis-hub-core` é o ponto único de entrada e orquestração de todo o ecossistema DcsProducer. Ela une:

- **Hub Core MetaRAG** (https://dcsproducer-hub-pqj9.vercel.app)
- **Camada AEGIS** (governança, proteção e inteligência transversal)
- **9 Pilares de Engenharia de Software**
- **Laboratórios práticos via sandbox**
- **Skills irmãs** (learning-orchestrator, system-design-master, six-pillars-engineer, career-gap-analyzer, pdf-wordpress-editor)

## 2. Onde visualizar

| Local | Caminho / Como acessar |
|-------|------------------------|
| Skill principal | `/.grok/skills/dcsproducer-aegis-hub-core/SKILL.md` |
| **Script Geral de Governança** | `scripts/aegis_orchestrator.py` (`--init` / `--status` / `--lab`) |
| Visual 9 Pilares | `references/9-pilares-visual.md` ou `artifacts/9-pilares-dcsproducer.md` |
| Fundamentos (este doc) | `references/fundamentos-e-funcionalidades.md` |
| Lab guides | `references/lab-01-*.md` e pastas em `artifacts/lab-0X-*` |
| PDF / HTML gerados | `artifacts/dcsproducer-*-*.pdf` e `.html` |
| Contexto de sessão AEGIS | `artifacts/aegis-session-context.json` |
| Progresso de aprendizado | `artifacts/dcs-learning-progress.json` |

## 3. Como aplicar no ecossistema

### 3.1 Ativação
Mencione qualquer um dos triggers:
- `dcsproducer-aegis-hub-core`
- AEGIS
- Hub Core
- 9 pilares
- laboratório sandbox
- integrar ecossistema DcsProducer

### 3.2 Script Geral de Governança (obrigatório no início de qualquer conversa)

```bash
# Inicializa sessão + alinhamento coordenado de produção
python scripts/aegis_orchestrator.py --init

# Snapshot de status
python scripts/aegis_orchestrator.py --status

# Prepara lab específico sob gate AEGIS
python scripts/aegis_orchestrator.py --lab 01

# Saída JSON (para integração)
python scripts/aegis_orchestrator.py --init --json
```

O script interliga automaticamente Hub Core + 9 Pilares + AEGIS Layer + todas as skills irmãs + labs validados, sob a Governança principal de produção. Contexto salvo em `artifacts/aegis-session-context.json`.

### 3.3 Fluxo típico de uso
1. **Init AEGIS** (`scripts/aegis_orchestrator.py --init`)
2. Diagnóstico do pilar / módulo do Hub em foco
3. Orquestração coordenada (extrai do Hub, aplica vocabulário dos 9 pilares + AEGIS, respeita gate)
4. Execução de laboratório no sandbox (quando pedido)
5. Registro contínuo nas skills irmãs
6. Documentação formal via `pdf-wordpress-editor`

### 3.4 Integração com skills irmãs

| Skill irmã | Quando é acionada |
|------------|-------------------|
| `dcs-learning-orchestrator` | Planos de estudo, competências, progresso de módulos do Hub |
| `dcs-system-design-master` | Decisões de arquitetura, escala, RAG, agentes |
| `six-pillars-engineer` | Vocabulário dos pilares, checklist de revisão de outputs de IA |
| `career-gap-analyzer` | Gaps, metas OKR/SMART, competências desenvolvidas |
| `pdf-wordpress-editor` | Relatórios, PDFs, HTML WordPress, planilha Lista_Projetos |

### 3.4 Os 9 Pilares + AEGIS

```
01 DevOps
02 Microsserviços
03 Serverless
04 Orquestração de Containers
05 Arquitetura Limpa
06 Domain-Driven Design
07 Observability          ← novo
08 DevSecOps              ← novo
09 Event-Driven Architecture ← novo

[AEGIS LAYER] — transversal a todos
```

### 3.5 Laboratórios disponíveis

| Lab | Nome | Portas sugeridas | Status |
|-----|------|------------------|--------|
| 01 | Observability + RAG | 8000 | Validado |
| 02 | DevSecOps + Agentic System | 8002 | Validado |
| 03 | Event-Driven + Generative Agents | 8003 | Validado |
| 04 | Arquitetura Limpa + Containers | 8004 | Validado |

Cada lab possui:
- Separação de camadas (quando aplicável)
- Endpoints `/health` + funcionalidade principal
- Script `run.sh`
- Código testado no sandbox

## 4. Funcionalidades principais

- Orquestração total do ecossistema em um único ponto de entrada
- Vocabulário unificado dos 9 pilares + AEGIS
- Laboratórios hands-on no sandbox remoto
- Registro contínuo de competências e progresso
- Geração de documentação premium (PDF/HTML) com brand DcsProducer®
- Integração nativa com Hub MetaRAG e planilha de projetos

## 5. Próximos passos de evolução

- Conectar labs a um LLM real (em vez de mocks)
- Persistência de eventos (Redis / Kafka)
- Observability completa (OpenTelemetry)
- CI/CD dos labs via GitHub Actions
- Dashboard React do Hub Core + AEGIS
