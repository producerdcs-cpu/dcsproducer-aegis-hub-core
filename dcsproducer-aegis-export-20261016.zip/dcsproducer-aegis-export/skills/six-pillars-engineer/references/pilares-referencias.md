# Referências Oficiais e Livros — 6 Pilares

## 01 · DevOps
- **Livro**: *The Phoenix Project* — Gene Kim, Kevin Behr, George Spafford
- **Livro**: *The DevOps Handbook* — Gene Kim et al.
- **Docs**: https://www.atlassian.com/devops
- **Docs**: https://docs.github.com/en/actions (CI/CD)

## 02 · Microsserviços
- **Livro**: *Building Microservices* — Sam Newman (2ª ed.)
- **Livro**: *Microservices Patterns* — Chris Richardson
- **Docs**: https://microservices.io/
- **Docs**: https://martinfowler.com/microservices/

## 03 · Serverless
- **Livro**: *Serverless Architectures on AWS* — Peter Sbarski
- **Docs**: https://docs.aws.amazon.com/lambda/
- **Docs**: https://cloud.google.com/functions/docs
- **Docs**: https://learn.microsoft.com/en-us/azure/azure-functions/

## 04 · Orquestração de Containers (Kubernetes)
- **Livro**: *Kubernetes in Action* — Marko Lukša
- **Livro**: *Kubernetes Patterns* — Bilgin Ibryam, Roland Huß
- **Docs oficiais**: https://kubernetes.io/docs/home/
- **Docs**: https://kubernetes.io/docs/concepts/overview/

## 05 · Arquitetura Limpa
- **Livro**: *Clean Architecture* — Robert C. Martin
- **Livro**: *Clean Code* — Robert C. Martin
- **Artigo**: https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html

## 06 · Domain-Driven Design
- **Livro**: *Domain-Driven Design* — Eric Evans (o “Blue Book”)
- **Livro**: *Implementing Domain-Driven Design* — Vaughn Vernon (o “Red Book”)
- **Docs / Site**: https://www.domainlanguage.com/
- **Artigo**: https://martinfowler.com/bliki/DomainDrivenDesign.html

## GenAI + MetaRAG (contexto Dcs Producer)
- Use os pilares acima como **contexto estruturado** ao montar o MetaRAG.
- Priorize trechos de linguagem ubíqua, contratos e checklists de revisão para reduzir alucinações e custo de tokens.
